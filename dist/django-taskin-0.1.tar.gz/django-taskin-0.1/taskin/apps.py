from django.apps import AppConfig


class TaskinConfig(AppConfig):
    name = 'taskin'
